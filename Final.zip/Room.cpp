#include "Room.hpp"

Room::~Room()
{

}